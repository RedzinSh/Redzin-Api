api = process.cwd()
//============[ MÓDULOS DA API ]==========\\
var express = require('express');
var router = express.Router();
var { exec } = require('child_process')
var fetch = require('node-fetch')
var fs = require('fs')

//PARA A ROTA DE PLAY DE ÁUDIO, VÍDEO E LINK
const {ytDonlodMp3,ytDonlodMp4,ytPlayMp3,ytPlayMp4,ytSearch} = require("./lib/youtube");

//ESSENCIAL 
const criador = ['Redzin']//Nome do criador/dono
const key = 'Redziny' //key da tua api
const keyApi = 'DarkStars' //key da api dark stars

//RESPOSTAS RAPIDAS
resposta = {
    semkey: {
        status: false,
        criador: `${criador}`,
        código: 406,
        mensagem: 
        'Faltou A "apikey" Na Url'
    },
    error: {
       status: false,
        criador: `${criador}`,
        mensagem: 
        'Erro No Servidor, Espere O Redzin Concertar...'
    }
}

//KEY INVÁLIDO OU SEM APIKEY 
var keyinvalida = api + '/public/SemKey.html'

//===================================================\\
const getBuffer = async (url) => {
  const response = await fetch(url);
  if (!response.ok) throw new Error('Failed to fetch image');
  return await response.buffer();
};

async function fetchJson (url, options) {
    try {
        options ? options : {}
        const res = await axios({
            method: 'GET',
            url: url,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}          


//=================[ COMEÇO DAS ROTAS ]============\\

router.get('/api/ytmp3', async(req, res, next) => {
 var cdapikey = req.query.apikey;
 link = req.query.link          
if(!cdapikey) return res.json(resposta.semkey)
 if(cdapikey !== key) return res.sendFile(keyinvalida)
 if (!link) return res.json({ status : false, criador : `Redzin`, mensagem : "Coloque O Link"})
 ytDonlodMp3(link).then((akk) => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: akk
})}).catch(e => {
res.sendFile(error)})})

 router.get('/api/ytmp4', async(req, res, next) => {
 var cdapikey = req.query.apikey;
 link = req.query.link          
if(!cdapikey) return res.json(resposta.semkey)
 if(cdapikey !== key) return res.sendFile(keyinvalida)
 if (!link) return res.json({ status : false, criador : `Redzin`, mensagem : "Coloque O Link"})
 ytDonlodMp4(link).then((akk) => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: akk
})}).catch(e => {
res.sendFile(error)})})

 router.get('/api/play', async(req, res, next) => {
 var cdapikey = req.query.apikey;
 nome = req.query.nome
if(!cdapikey) return res.json(resposta.semkey)
 if(cdapikey !== key) return res.sendFile(keyinvalida)
 if (!nome) return res.json({ status : false, criador : `criador`, mensagem : "Coloque O Nome"})
 ytPlayMp3(nome).then((akk) => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: akk
})}).catch(e => {
res.sendFile(error)})})

 router.get('/api/playvd', async(req, res, next) => {
 var cdapikey = req.query.apikey;
 nome = req.query.nome
if(!cdapikey) return res.json(resposta.semkey)
 if(cdapikey !== key) return res.sendFile(keyinvalida)
 if (!nome) return res.json({ status : false, criador : `Redzin`, mensagem : "Coloque O Nome"})
 ytPlayMp4(nome).then((akk) => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: akk
})}).catch(e => {
res.sendFile(error)})})

router.all('/api/pinterest', async (req, res) => {
  const cdapikey = req.query.apikey;
  const texto = req.query.texto;
  try {
    if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
    if (!texto) return res.json({ status: false, mensagem: 'falta o parâmetro "texto"' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
    try {
      const imageUrl = `http://br2.bronxyshost.com:4109/api/pesquisa/pinterest?text=${texto}&apikey=${keyApi}`;
      const buffer = await getBuffer(imageUrl);
      res.type('png');
      res.send(buffer);
    } catch (e) {
      console.error('Erro ao obter a imagem:', e);
      res.status(500).json({ status: false, mensagem: 'Erro ao obter a imagem' });
    }
  } catch (error) {
    console.error('Erro no endpoint:', error);
    res.status(500).json({ status: false, mensagem: "Erro interno ao processar a solicitação." });
  }
});

router.all('/api/audiomeme', async (req, res) => {
const cdapikey = req.query.apikey;
const texto = req.query.texto;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!texto) return res.json({ status: false, mensagem: 'falta o parâmetro "texto"' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/download/myinstants?query=${texto}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data.resultado
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/youtube', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/pesquisa/youtube?query=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data.resultado
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/filme', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/filme?nome=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/serie', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/filme?nome=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/igstalk', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/pesquisa/insta-stalker/v3?usuario=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/pensador', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/pesquisa/pensador?query=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});
router.all('/api/wallpaper', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/pesquisa/wallpaper?query=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});





router.all('/api/metadinha', async (req, res) => {
const cdapikey = req.query.apikey;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/metadinha?apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/qr-code', async (req, res) => {
  const cdapikey = req.query.apikey;
  const nome = req.query.nome;
  try {
    if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
    if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
    try {
      const imageUrl = `http://br2.bronxyshost.com:4109/creator/qr-code?texto=${nome}&apikey=${keyApi}`;
      const buffer = await getBuffer(imageUrl);
      res.type('png');
      res.send(buffer);
    } catch (e) {
      console.error('Erro ao obter a imagem:', e);
      res.status(500).json({ status: false, mensagem: 'Erro ao obter a imagem' });
    }
  } catch (error) {
    console.error('Erro no endpoint:', error);
    res.status(500).json({ status: false, mensagem: "Erro interno ao processar a solicitação." });
  }
});

router.all('/api/tempo', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/tempo?city=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/simih', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/outros/simih?language=pt&text=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

router.all('/api/turbo', async (req, res) => {
const cdapikey = req.query.apikey;
const nome = req.query.nome;
if (!cdapikey) return res.json({ status: false, mensagem: 'Faltou Insirir Sua apikey"' });
if (!nome) return res.json({ status: false, mensagem: 'Faltou O Nome' });
    if(cdapikey !== key) return res.sendFile(keyinvalida)
  try {
fetch(`http://br2.bronxyshost.com:4109/api/turbo?text=${nome}&apikey=${keyApi}`)
      .then(response => response.json())
      .then(data => {
        res.json({
          resultado: data
        });
      })
  } catch (error) {
console.error(error);
res.status(500).json({ status: false, message: "Erro Ao Processar A Requisição" });
  }
});

//========\\

router.all('*', async (req, res) => {
res.status(404).json({
status:404,
error: 'Esta Página Não Está Presente Ma Rest Api',
endpoint: req.path
})
})

//============[ ATUALIZAÇÃO DO ARQUIVO "INDEX.JS" ]===========\\
fs.watchFile('./api.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log('O arquivo index foi editado. Reiniciando...');
process.exit();
}
});

//========\\

module.exports = router

/*
E..
a base e isso kkk
não e muita coisa porém ja da pra começar a fazer uma melhor
espero que gostem 🥰
*/
